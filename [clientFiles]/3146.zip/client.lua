function ReplaceCar()
txd = engineLoadTXD('kart.txd', 571)
engineImportTXD(txd, 571)
dff = engineLoadDFF('kart.dff', 571)
engineReplaceModel(dff, 571)
end
addEventHandler( 'onClientResourceStart', getResourceRootElement(getThisResource()), ReplaceCar)