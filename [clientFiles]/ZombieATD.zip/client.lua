
ZombiePedSkins={
{"z1",13}, -- optimize
{"z2",22}, -- optimize
{"z5",68}, -- optimize
{"z6",69}, -- optimize
{"z7",70}, -- optimize
{"z9",97}, -- optimize
{"z10",105},  -- optimize
{"z11",107}, -- optimize
{"z12",108}, -- optimize
{"z13",126}, -- optimize
{"z14",127},  -- optimize
{"z15",128}, -- optimize
{"z16",152}, -- optimize
}

function replaceModel() 
			for i, skin in ipairs(ZombiePedSkins) do	
			local zombieTXD = engineLoadTXD("skins/"..skin[1]..".txd")
			engineImportTXD(zombieTXD, skin[2])
			local zombieDFF = engineLoadDFF("skins/"..skin[1]..".dff", skin[2])
			engineReplaceModel(zombieDFF, skin[2])
						
			end
end
addEventHandler ( "onClientResourceStart", getResourceRootElement(getThisResource()), replaceModel)