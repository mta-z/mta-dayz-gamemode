rootElement = getRootElement()
thisResource = getThisResource()
thisResourceRoot = getResourceRootElement(thisResource)
